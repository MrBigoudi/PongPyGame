﻿import pygame
from pygame.locals import *

def afficheScore(s1, s2):
    """ Affiche les scores du joueur 1 et 2"""
    fenetre.blit(haut, (0,0))
    font=pygame.font.Font(pygame.font.match_font('arialblack'), 100, bold=True)
    text = font.render(str(s1),True,(230,170, 230))
    l,h = font.size(str(s1))
    fenetre.blit(text, (250-l//2,50-h//2))
    text = font.render(str(s2),True,(230,170, 170))
    l,h = font.size(str(s2))
    fenetre.blit(text, (750-l//2,50-h//2))


def enfoncee(key):
    """
    Fonction qui est déclenchée lorsque on appuie sur
    une touche. On met à  jour la liste Touches
    """
    if not key in Touches:
        Touches.append(key)

def relachee(key):
    """
    Fonction qui est déclenchée lorsque on relâche une
    touche. On met à  jour la liste Touches
    """
    if key in Touches:
        Touches.remove(key)

pygame.init()
fenetre = pygame.display.set_mode((1000,600))

# Déclaration des variables globales
continuer = True
Touches = []

# Chargement des images
haut = pygame.image.load("haut.png").convert()
fenetre.blit(haut, (0,0))
gauche = pygame.image.load("gauche.png").convert()
fenetre.blit(gauche, (0,100))
terrain = pygame.image.load("centre.png").convert()
fenetre.blit(terrain, (100,100))
droite = pygame.image.load("droite.png").convert()
fenetre.blit(droite, (900,100))

balle = pygame.image.load("balle.png").convert_alpha()
P1 = pygame.image.load("R1.png").convert_alpha()
P2 = pygame.image.load("R2.png").convert_alpha()
clock = pygame.time.Clock()
while continuer:
    clock.tick(100)
    for event in pygame.event.get():
        if event.type == QUIT :
            continuer = False
        elif event.type == KEYDOWN :
            enfoncee(event.key)
        elif event.type == KEYUP :
            relachee(event.key)
    # ici on réalise l'animation
    # Mise à jour de l'écran
    pygame.display.flip()
print('Fin')
pygame.quit()